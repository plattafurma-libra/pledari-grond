INSERT INTO `tut` (`DStichwort`, `DStichwortSort`, `DSemantik`, `DSubsemantik`, `RStichwort`, `RStichwortSort`, `RGenus`, `RSemantik`, `RSubsemantik`, `RGrammatik`, `nr`) VALUES
('ϣⲁ̄ⲓ̈', '', '', '', 'tea', '', '', '', '', '', 276),
('ϣⲁ̄ⲓ̈ ⲓⲛⲇⲟ ⲇⲁ̄ⲛ', '', '', '', 'here is tea', '', '', '', '', '', 276),
('ⲙⲉⲇⲣⲉⲥⲁ', '', '', '', 'school', '', '', '', '', '', 276),
('ⲙⲉⲇⲣⲉⲥⲁ ⲭⲁⲛⲛⲁ̄ⲅⲓⲣ ⲇⲁ̄ⲛ', '', '', '', 'there is a school in Khannaag', '', '', '', '', '', 276),
('ⳝⲉⲗⲗⲓ', '', '', '', 'work', '', '', '', '', '', 276),
('ⳝⲉⲗⲗⲓ ⲇⲁ̄ⲙⲟⲩⲛ', '', '', '', 'there is no work', '', '', '', '', '', 276),
('ⲕⲟⲩⲃⲕⲉⲇ ⲇⲁ̄ⲛ', '', '', '', 'he is coming by boat', '', '', '', '', '', 276);
